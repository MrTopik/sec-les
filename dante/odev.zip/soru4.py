i = 1
toplam = 0

while i <= 50:
    print(i)
    toplam += i
    i += 1

print("\nToplam:", toplam)