for i in range(1, 11):
    for x in range(1, 11):
        print(f"{i} x {x} = {i * x}")
    print("-" * 15)