bolunenler_2 = []
bolunenler_5 = []
toplam=0
adet=0
for i in range(100, 201):
    if i % 2 == 0:
        print(i , ",2'ye bölünebilir")
        toplam+=i
        adet+=1
    if x % 5 == 0:
        print(x , ",5'ye bölünebilir")
        toplam+=x
        adet+=1
print(f"{adet} adet sayı var,bunların ortalaması {toplam/adet}")