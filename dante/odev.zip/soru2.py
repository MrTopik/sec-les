toplam = 0
sayi = int(input("Bir sayı girin (0'da program biter): "))
while sayi != 0:
    toplam += sayi
    sayi = int(input("Bir sayı girin(0'da program biter): "))
print("Toplam:", toplam)