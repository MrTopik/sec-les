sayi = int(input("Faktöriyeli hesaplanacak sayıyı girin: "))
faktoriyel = 1
i = 1

while i <= sayi:
    faktoriyel *= i
    i += 1

print(f"{sayi}! = {faktoriyel}")